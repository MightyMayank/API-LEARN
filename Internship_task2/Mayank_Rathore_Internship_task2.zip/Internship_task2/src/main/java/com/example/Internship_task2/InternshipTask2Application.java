package com.example.Internship_task2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternshipTask2Application {

	public static void main(String[] args) {
		SpringApplication.run(InternshipTask2Application.class, args);
	}

}
